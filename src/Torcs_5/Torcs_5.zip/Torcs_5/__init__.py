import scl
def main():
    scl.init()
