'''
    Generated automatically by Splash Code Generator for default_build_unit
'''
from .splash.build_unit.default_build_unit import DefaultBuildUnit

def main(args=None):
    build_unit = DefaultBuildUnit()
    build_unit.run()

